# Five-Minute Presentation Talking Points

1. Introduce the business problem: manual flight/weather reporting is slow and fragmented.
2. Explain the data sources: monthly flight performance plus weather observations.
3. Walk through architecture: ETL to PostgreSQL, reporting view, Dash dashboard.
4. Highlight schema: airport and month dimensions support flight/weather facts.
5. Explain validation: required columns, ranges, non-negative counts, logging.
6. Demonstrate dashboard tabs: KPI cards, performance trends, weather relationship, table.
7. Share insight: summer months show weaker on-time rates and higher delayed percentages in the sample.
8. Close with business value: repeatable pipeline, cleaner reporting, faster stakeholder decisions.
