"""ETL pipeline for CVG flight and weather analytics.

This script is production-oriented scaffolding for the final repository. It executes
SQL load scripts against PostgreSQL and writes clear logs for troubleshooting.
"""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import create_engine, text

ROOT = Path(__file__).resolve().parents[1]
LOG_PATH = ROOT / "logs" / "pipeline.log"
SQL_DIR = ROOT / "sql"

LOG_PATH.parent.mkdir(exist_ok=True)
logging.basicConfig(
    filename=LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)


def get_engine():
    load_dotenv(ROOT / ".env")
    url = os.getenv("POSTGRES_URL")
    if not url:
        raise RuntimeError("POSTGRES_URL is missing. Copy .env.example to .env and update it.")
    return create_engine(url, pool_pre_ping=True)


def run_sql_file(engine, sql_file: Path) -> None:
    sql = sql_file.read_text(encoding="utf-8")
    with engine.begin() as conn:
        conn.execute(text(sql))
    logging.info("Executed SQL file: %s", sql_file.name)


def main() -> None:
    logging.info("Starting CVG ETL load")
    engine = get_engine()
    run_sql_file(engine, SQL_DIR / "initial_postgresql_load_script.sql")
    run_sql_file(engine, SQL_DIR / "create_reporting_view.sql")
    logging.info("CVG ETL load completed successfully")


if __name__ == "__main__":
    main()
