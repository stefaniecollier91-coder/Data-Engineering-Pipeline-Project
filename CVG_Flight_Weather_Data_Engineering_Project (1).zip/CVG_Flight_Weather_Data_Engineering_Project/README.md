# CVG Flight Delays & Weather Analytics Data Engineering Project

## Executive Summary
This project builds an end-to-end analytics pipeline for Cincinnati/Northern Kentucky International Airport (CVG). It combines monthly flight performance data with weather observations, stores the integrated data in PostgreSQL, validates reporting quality, and presents results in an interactive Plotly Dash dashboard.

## Business Problem
Operations stakeholders need a clear way to see which months have weaker on-time performance, higher delay percentages, cancellations, diversions, and weather-related disruption patterns. Manual reporting across separate data sources is slow and inconsistent.

## Repository Structure

```text
CVG_Flight_Weather_Data_Engineering_Project/
├── data/                  # data notes / raw data location
├── notebooks/             # optional exploratory notebooks
├── sql/                   # PostgreSQL schema, seed data, reporting view
├── etl/                   # ETL runner
├── validation/            # validation framework
├── dash_app/              # Dash application
├── docs/                  # proposal, source plan, ERD, schema docs, architecture docs
├── images/                # screenshots and demo images
├── logs/                  # local runtime logs
├── README.md
├── requirements.txt
└── .gitignore
```

## Data Sources
- Monthly flight performance data for CVG
- Weather observations aggregated to month
- PostgreSQL reporting view: `vw_monthly_flight_weather_summary`

## Pipeline Architecture
1. Load raw/sample flight and weather records with `sql/initial_postgresql_load_script.sql`.
2. Create the reporting view with `sql/create_reporting_view.sql`.
3. Run validation checks from `validation/validate_reporting_view.py`.
4. Launch the dashboard from `dash_app/app.py`.

## Setup Instructions

### 1. Clone and open the project
```bash
git clone <your-github-repo-link>
cd CVG_Flight_Weather_Data_Engineering_Project
```

### 2. Create and activate a virtual environment
Windows:
```bash
python -m venv .venv
.venv\Scripts\activate
```
Mac/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure the database connection
```bash
copy .env.example .env
```
Edit `.env`:
```text
POSTGRES_URL=postgresql+psycopg2://postgres:your_password@localhost:5432/cvg_flight_weather
ALLOW_SAMPLE_FALLBACK=false
```

### 5. Load PostgreSQL tables and reporting view
```bash
python etl/extract_transform_load.py
```

### 6. Run validation
```bash
python validation/validate_reporting_view.py
```

### 7. Run the Dash dashboard
```bash
python dash_app/app.py
```
Open: `http://127.0.0.1:8050/`

## Dashboard Features
- KPI cards for total operations, on-time rate, arrival delays, and severe weather days
- Season filter
- Monthly performance trend chart
- Disruption comparison chart
- Weather relationship tab
- Data table tab

## Key Insight
In the sample data, June and July show lower on-time performance and higher delayed percentages than the earlier months, suggesting the dashboard is useful for identifying seasonal disruption risk.

## Included Deliverables
- Project proposal
- Data source plan
- ER diagram
- Database schema documentation
- SQL load scripts
- ETL runner
- Validation framework
- Logging/error handling
- Dash application
- Screenshots/demo materials
- Architecture overview

## AI Use Note
ChatGPT was used to help organize repository documentation, presentation structure, and final wording. The project topic, transportation/flight operations context, data engineering design, and dashboard implementation are based on the course deliverables and project work.
