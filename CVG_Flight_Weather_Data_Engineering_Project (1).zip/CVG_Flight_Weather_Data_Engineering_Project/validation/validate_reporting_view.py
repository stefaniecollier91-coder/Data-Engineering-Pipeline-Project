"""Validation checks for the CVG reporting view."""

import logging
import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

ROOT = Path(__file__).resolve().parents[1]
LOG_PATH = ROOT / "logs" / "pipeline.log"
LOG_PATH.parent.mkdir(exist_ok=True)
logging.basicConfig(filename=LOG_PATH, level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

REQUIRED_COLUMNS = {
    "airport_code", "airport_name", "year_number", "month_number", "month_name", "season",
    "flight_operations", "on_time_arrivals", "on_time_pct", "arrival_delays", "delayed_pct",
    "flight_cancelled", "cancelled_pct", "diverted_flights", "avg_temperature_f",
    "total_precipitation_inches", "total_snowfall_inches", "avg_wind_speed_mph", "severe_weather_days",
}


def get_engine():
    load_dotenv(ROOT / ".env")
    url = os.getenv("POSTGRES_URL")
    if not url:
        raise RuntimeError("POSTGRES_URL is missing. Copy .env.example to .env and update it.")
    return create_engine(url, pool_pre_ping=True)


def validate(df: pd.DataFrame) -> list[str]:
    errors: list[str] = []
    missing = REQUIRED_COLUMNS.difference(df.columns)
    if missing:
        errors.append(f"Missing required columns: {sorted(missing)}")
    if df.empty:
        errors.append("Reporting view returned zero rows")
    if "month_number" in df and not df["month_number"].between(1, 12).all():
        errors.append("Month number outside 1-12")
    for col in ["on_time_pct", "delayed_pct", "cancelled_pct"]:
        if col in df and not df[col].dropna().between(0, 100).all():
            errors.append(f"{col} contains values outside 0-100")
    for col in ["flight_operations", "on_time_arrivals", "arrival_delays", "flight_cancelled", "diverted_flights", "severe_weather_days"]:
        if col in df and (df[col].dropna() < 0).any():
            errors.append(f"{col} contains negative values")
    return errors


def main() -> None:
    engine = get_engine()
    with engine.connect() as conn:
        df = pd.read_sql(text("SELECT * FROM vw_monthly_flight_weather_summary"), conn)
    errors = validate(df)
    if errors:
        for err in errors:
            logging.error(err)
        raise SystemExit("Validation failed. See logs/pipeline.log.")
    logging.info("Validation passed for %s reporting rows", len(df))
    print(f"Validation passed for {len(df)} reporting rows.")


if __name__ == "__main__":
    main()
