Raw data files are not committed in this sample repository. The SQL load script contains the sample records used to reproduce the PostgreSQL database.
