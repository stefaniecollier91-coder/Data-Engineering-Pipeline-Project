Exploratory notebooks can be stored here. Final production logic is kept in the `etl/` and `validation/` folders.
